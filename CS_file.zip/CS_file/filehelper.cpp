#include<iostream>
#include<stdio.h>
#include<stdlib.h>

#include <WINSOCK2.H>
#include<windows.h>
#pragma  comment(lib,"ws2_32.lib")
#define _MAX 256
class FileHelper
{
private:
	FILE *f;
	char path_buffer[_MAX];
	char drive[_MAX];
	char dir[_MAX];
	char fname[_MAX];
	char ext[_MAX];
 
public:
	FILE * selectfile()
	{
		printf("������Ҫ���͵��ļ���\n");
		scanf("%s",path_buffer);
 
		if (f=fopen(path_buffer,"rb"))
		{
			printf("�ļ��򿪳ɹ�\n");
			return f;
		}
		else
		{
			printf("�ļ������ڣ�����������\n");
			return selectfile();
		}
	}
 
	char * getFileName()
	{
		_splitpath(path_buffer, drive, dir, fname, ext);
		return strcat(fname, ext);
	}
	FILE * createFile(char *name)
	{
		remove(name);
		if (f = fopen(name, "ab"))
		{
			printf("�ļ������ɹ�\n");
 
		}
		else
		{
			printf("�ļ�����ʧ��\n");
		}
		return f;
	}
 
	bool createDir(char *dir)
	{
		char head[MAX_PATH] = "md ";
		return system(strcat(head, dir));
	}
    FILE* edit_path_buff(char *s){
    	strcpy(path_buffer,s);
    	f=fopen(path_buffer,"rb");
    	return f;
	}
 
};


