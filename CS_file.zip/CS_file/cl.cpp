#include <stdio.h>
#include <WINSOCK2.H>
#include <STDIO.H>
#include<time.h>
#include "filehelper.cpp"
#include<iostream>

#pragma  comment(lib,"ws2_32.lib")
using namespace std;

void rec_file(FileHelper &fh,SOCKET sclient)
{
	FILE *f=fh.selectfile();
	char sendData[BUFSIZ];
	char recData[BUFSIZ];
	char over[BUFSIZ] = "Finnal";
	char * name = fh.getFileName();
	strcpy(sendData, name);
	printf("%s\n", sendData);
	int nCount;
	long long sum = 0;
	send(sclient, sendData, strlen(sendData)+1, 0);
	int ret = recv(sclient, recData, BUFSIZ, 0);
	printf(recData);
	while ((nCount=fread(sendData,1,BUFSIZ,f))>0)
	{
		printf("%db\n",sum+=nCount);
		
		send(sclient, sendData, nCount, 0);
		
		int ret = recv(sclient, recData, BUFSIZ, 0);
		if (ret >0)
		{
			
			//recData[ret] = 0x00;
			printf(recData);
		}
		else
		{
			printf("�������ʧȥ����");
			break;
		}
	}
	send(sclient, over, BUFSIZ, 0);
	ret = recv(sclient, recData, BUFSIZ, 0);
	if (ret>0&&strcmp(recData,over)==0)
	{
		printf("����ɹ���");
	}
	fclose(f);
}

void sd_file(FileHelper &fh,SOCKET sClient,sockaddr_in remoteAddr)
{
	char revData[BUFSIZ];
	int ret = 0;
	long long count = 0;
	char sendData[BUFSIZ] = "��ã�TCP�ͻ��ˣ�\n";
	ret = recv(sClient, revData, BUFSIZ, 0);
	char fromname[BUFSIZ] = {};
	strcpy(fromname, revData);
	char mid[3] = "\\";
	char finame[MAX_PATH] = {};
	char over[BUFSIZ] = "Finnal";
	strcat(finame, inet_ntoa(remoteAddr.sin_addr));
	printf(finame);
	strcat(finame, mid);
	strcat(finame, revData);
	//printf(finame);
	FILE *f = fh.createFile(finame);
	send(sClient, sendData, BUFSIZ, 0);
	while ((ret = recv(sClient, revData, BUFSIZ, 0)) > 0)
	{
		//printf("%d\n", ret);
		printf("%db\n", count += ret);
		if (strcmp(revData,over)==0)
		{
			printf("�ļ�%s����ɹ�\n", fromname);
			break;
			send(sClient, over, BUFSIZ, 0);
		}
		fwrite(revData, 1, ret, f);
		send(sClient, sendData, BUFSIZ, 0);
	}
	fclose(f);
	if (strcmp(revData, over) != 0)
	{
		printf("IP��%s������%s���������ʧȥ����\n", inet_ntoa(remoteAddr.sin_addr),fromname);
		remove(finame);
	}
}



int main(int argc, char* argv[])
{
	char sendData[BUFSIZ];
	char recData[BUFSIZ];
	WORD sockVersion = MAKEWORD(2,2);//�汾��
	WSADATA data;    //��������WSAStartup���ú󷵻ص�windows Sockets����
	FileHelper fh;
	if(WSAStartup(sockVersion, &data) != 0)
	{
		return 0;
	}
 
	sockaddr_in serAddr;
	serAddr.sin_family = AF_INET;
	serAddr.sin_port = htons(8888);
	serAddr.sin_addr.S_un.S_addr = inet_addr("127.0.0.1"); 
 
	while (true)
	{
		SOCKET sclient = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
		if (sclient == INVALID_SOCKET)
		{
			printf("invalid socket !");
			return 0;
		}
		if (connect(sclient, (sockaddr *)&serAddr, sizeof(serAddr)) == SOCKET_ERROR)
		{
			printf("connect error !");
			closesocket(sclient);
			return 0;
		}
		
		clock_t st_time,end_time;
        st_time=clock();
        int Length=recv(sclient,recData,BUFSIZ,0);
        printf("��������������Ϣ��\n%s\n",recData);
        
        scanf("%c",&sendData[0]);
        sendData[1]='\0';
        send(sclient,sendData,1024,0);
        
        char a=sendData[0];
        memset(sendData,0,1024);
		
		if(a=='0'){
			closesocket(sclient);
			break;
		}
		if(a=='1'){
			rec_file(fh,sclient);
		}
		if(a=='2'){
			sd_file(fh,sclient,serAddr);
		}
		
		closesocket(sclient);
	}
	WSACleanup();
	return 0;
}
