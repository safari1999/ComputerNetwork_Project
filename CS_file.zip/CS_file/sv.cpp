#include <stdio.h>
#include <stdio.h>
#include <winsock2.h>
#include "filehelper.cpp"
#pragma comment(lib,"ws2_32.lib")

void rec_file(FileHelper &fh,SOCKET sclient,sockaddr_in remoteAddr)
{
	FILE *f=fh.selectfile();
	char sendData[BUFSIZ];
	char recData[BUFSIZ];
	char over[BUFSIZ] = "Finnal";
	char * name = fh.getFileName();
	strcpy(sendData, name);
	printf("%s\n", sendData);
	int nCount;
	long long sum = 0;
	send(sclient, sendData, strlen(sendData)+1, 0);
	int ret = recv(sclient, recData, BUFSIZ, 0);
	printf(recData);
	while ((nCount=fread(sendData,1,BUFSIZ,f))>0)
	{
		printf("%db\n",sum+=nCount);
		
		send(sclient, sendData, nCount, 0);
		
		int ret = recv(sclient, recData, BUFSIZ, 0);
		if (ret >0)
		{
			
			//recData[ret] = 0x00;
			printf(recData);
		}
		else
		{
			printf("�������ʧȥ����");
			break;
		}
	}
	send(sclient, over, BUFSIZ, 0);
	ret = recv(sclient, recData, BUFSIZ, 0);
	if (ret>0&&strcmp(recData,over)==0)
	{
		printf("����ɹ���");
	}
	fclose(f);
}

void sd_file(FileHelper &fh,SOCKET sClient,sockaddr_in remoteAddr)
{
	char revData[BUFSIZ];
	int ret = 0;
	long long count = 0;
	char sendData[BUFSIZ] = "��ã�TCP�ͻ��ˣ�\n";
	ret = recv(sClient, revData, BUFSIZ, 0);
	char fromname[BUFSIZ] = {};
	strcpy(fromname, revData);
	char mid[3] = "\\";
	char finame[MAX_PATH] = {};
	char over[BUFSIZ] = "Finnal";
	strcat(finame, inet_ntoa(remoteAddr.sin_addr));
	printf(finame);
	strcat(finame, mid);
	strcat(finame, revData);
	//printf(finame);
	FILE *f = fh.createFile(finame);
	send(sClient, sendData, BUFSIZ, 0);
	while ((ret = recv(sClient, revData, BUFSIZ, 0)) > 0)
	{
		//printf("%d\n", ret);
		printf("%db\n", count += ret);
		if (strcmp(revData,over)==0)
		{
			printf("�ļ�%s����ɹ�\n", fromname);
			break;
			send(sClient, over, BUFSIZ, 0);
		}
		fwrite(revData, 1, ret, f);
		send(sClient, sendData, BUFSIZ, 0);
	}
	fclose(f);
	if (strcmp(revData, over) != 0)
	{
		printf("IP��%s������%s���������ʧȥ����\n", inet_ntoa(remoteAddr.sin_addr),fromname);
		remove(finame);
	}
}














int main(int argc, char* argv[])
{
	//��ʼ��WSA
	WORD sockVersion = MAKEWORD(2, 2);
	WSADATA wsaData;
	FileHelper fh;
	if (WSAStartup(sockVersion, &wsaData) != 0)
	{
		return 0;
	}
 
	//�����׽���
	SOCKET slisten = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (slisten == INVALID_SOCKET)
	{
		printf("socket error !");
		return 0;
	}
 
	//��IP�Ͷ˿�
	sockaddr_in sin;
	sin.sin_family = AF_INET;
	sin.sin_port = htons(8888);
	sin.sin_addr.S_un.S_addr = INADDR_ANY;
	if (bind(slisten, (LPSOCKADDR)&sin, sizeof(sin)) == SOCKET_ERROR)
	{
		printf("bind error !");
	}
 
	//��ʼ����
	if (listen(slisten, 5) == SOCKET_ERROR)
	{
		printf("listen error !");
		return 0;
	}
 
	//ѭ����������
	SOCKET sClient;
	sockaddr_in remoteAddr;
	int nAddrlen = sizeof(remoteAddr);
	char revData[BUFSIZ];
	while (true)
	{
		printf("�ȴ�����...\n");
		sClient = accept(slisten, (SOCKADDR *)&remoteAddr, &nAddrlen);
		if (sClient == INVALID_SOCKET)
		{
			printf("accept error !");
			continue;
		}
		printf("���ܵ�һ�����ӣ�%s \r\n", inet_ntoa(remoteAddr.sin_addr));
		/*if (fh.createDir(inet_ntoa(remoteAddr.sin_addr)))
			printf("�ļ��д����ɹ���");*/
			
		char menu[BUFSIZ] = "��ѡ����Ҫ����������еĲ�����\n>0 �˳�����\n>1 �����ļ� \n>2 �ϴ��ļ�\n��ظ��������֡�\n"; 
		send(sClient, menu,BUFSIZ, 0);	
		
		recv(sClient,revData,1024,0);
		if(revData[0]=='0') break;
		if(revData[0]=='1'){
			sd_file(fh,sClient,remoteAddr);
		}
		if(revData[0]=='2'){
			rec_file(fh,sClient,remoteAddr);
		}
		
		closesocket(sClient);
	}
 
	closesocket(slisten);
	WSACleanup();
	return 0;
}
