#include<iostream>
#include<stdio.h>
#include<stdlib.h>

#include <WINSOCK2.H>
#include<windows.h>
#pragma  comment(lib,"ws2_32.lib")
#define _MAX 256
class FileHelper
{
private:
	FILE *f;
	char path_buffer[_MAX];
	char drive[_MAX];
	char dir[_MAX];
	char fname[_MAX];
	char ext[_MAX];
 
public:
	FILE * selectfile()
	{
		printf("������Ҫ���͵��ļ���\n");
		scanf("%s",path_buffer);
 
		if (f=fopen(path_buffer,"rb"))
		{
			printf("�ļ��򿪳ɹ�\n");
			return f;
		}
		else
		{
			printf("�ļ������ڣ�����������\n");
			return selectfile();
		}
	}
 
	char * getFileName()
	{
		_splitpath(path_buffer, drive, dir, fname, ext);
		return strcat(fname, ext);
	}
	FILE * createFile(char *name)
	{
		remove(name);
		if (f = fopen(name, "ab"))
		{
			printf("�ļ������ɹ�\n");
 
		}
		else
		{
			printf("�ļ�����ʧ��\n");
		}
		return f;
	}
 
	bool createDir(char *dir)
	{
		char head[MAX_PATH] = "md ";
		return system(strcat(head, dir));
	}
    FILE* edit_path_buff(char *s){
    	strcpy(path_buffer,s);
    	f=fopen(path_buffer,"rb");
    	return f;
	}
 
};

void send_file(FileHelper& fh,SOCKET clntsock)
{
	//path preparation
	char path[1024];
	char err[]="0";
	char cor[]="1";
	FILE *f;
	for(;;){
		memset(path,0,1024);
		int len=recv(clntsock,path,strlen(path),0);
		path[len]='\0';
		//char *c="text.txt";
		for(int i=0;;i++)
		   if(path[i]=='\n'){
		   	    path[i]='\0';
		   	    break;
		   }
	    f=fh.edit_path_buff(path);
	    if(f){
	    	send(clntsock,cor,strlen(cor),0);
	    	break;
		}
		send(clntsock,err,strlen(err),0);
	}
	printf("%s",fh.getFileName());
	
	//send file
	char sendData[1024];
	char revData[1024];
	char over[1024]="Finnish transfering";
	char *name=fh.getFileName();
	strcpy(sendData,name);
	printf("%s\n",sendData);
	int nCount;
	long long sum=0;
	send(clntsock,sendData,strlen(sendData)+1,0);
	int ret=recv(clntsock,revData,1024,0);
	printf(revData);
	while( (nCount = fread(sendData, 1, 1024, f)) > 0 ){
		send(clntsock, sendData, nCount, 0);
	}
	send(clntsock,over,strlen(over),0);
	fclose(f);
	closesocket(clntsock);
}

void recv_file(FileHelper &fh,SOCKET csock,struct sockaddr_in other)
{
	char revData[1024];
	if(fh.createDir(inet_ntoa(other.sin_addr)))
	   printf("�ļ��д����ɹ���\n");
	int ret=0;
	long long cnt=0;
	
	ret=recv(csock,revData,1024,0);
	char tmp[1024]={};
	strcpy(tmp,revData);
	char filename[1024]={};
	strcpy(filename,inet_ntoa(other.sin_addr));
	char mid[3]="\\";
	strcat(filename,mid);
	strcat(filename,revData);
	printf(filename);
	FILE *f=fh.createFile(filename);
	send(csock,"��ã��ͻ���\n",1024,0);
	char over[1024]="Finnish transfering";
	while((ret=recv(csock,revData,1024,0))>0){
		if(strcmp(revData,over)==0){
			printf("�ļ�%s����ɹ�\n",filename);
			break;
			send(csock,over,1024,0);
		}
		fwrite(revData, 1, ret, f);
	}
	fclose(f);
	if(strcmp(revData,over)!=0){
		printf("IP:%s ������%s���������ʧȥ����\n",inet_ntoa(other.sin_addr),tmp);
		remove(filename) ;
	}
	closesocket(csock);
}
